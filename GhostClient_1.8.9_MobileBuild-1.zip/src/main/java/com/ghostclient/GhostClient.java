package com.ghostclient;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

@Mod(modid = "ghostclient", name = "GhostClient", version = "1.0.0", clientSideOnly = true)
public class GhostClient {
    public static boolean autoClick = false;
    public static boolean aimBot = false;
    public static boolean autoBridge = false;

    private int clickTimer = 0;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new AimBot());
        MinecraftForge.EVENT_BUS.register(new AutoBridge());
    }

    @SubscribeEvent
    public void key(InputEvent.KeyInputEvent event) {
        if (Keyboard.getEventKeyState()) {
            int k = Keyboard.getEventKey();
            if (k == Keyboard.KEY_R) autoClick = !autoClick;
            if (k == Keyboard.KEY_G) aimBot = !aimBot;
            if (k == Keyboard.KEY_B) autoBridge = !autoBridge;
        }
    }

    @SubscribeEvent
    public void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        if (autoClick && Mouse.isButtonDown(0)) {
            if (clickTimer-- <= 0) {
                if (net.minecraft.client.Minecraft.getMinecraft().thePlayer != null) {
                    net.minecraft.client.Minecraft.getMinecraft().clickMouse();
                }
                clickTimer = 2; // about 6-7 CPS; change if desired
            }
        } else {
            clickTimer = 0;
        }
    }
}
