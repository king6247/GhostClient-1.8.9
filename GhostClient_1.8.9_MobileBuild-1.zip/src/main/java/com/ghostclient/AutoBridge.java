package com.ghostclient;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class AutoBridge {
    private final Minecraft mc = Minecraft.getMinecraft();

    @SubscribeEvent
    public void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !GhostClient.autoBridge) return;
        if (mc.thePlayer == null || mc.theWorld == null || mc.playerController == null) return;

        // Basic safe bridge helper:
        // while moving forward, place a block against the block below/behind.
        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemBlock)) return;

        BlockPos below = new BlockPos(mc.thePlayer.posX,
                mc.thePlayer.posY - 1.0D, mc.thePlayer.posZ);

        if (!mc.theWorld.getBlockState(below).getBlock().isAir(mc.theWorld, below)) return;

        int x = MathHelperFloor(mc.thePlayer.posX);
        int z = MathHelperFloor(mc.thePlayer.posZ);

        BlockPos support = new BlockPos(x, below.getY(), z);
        for (EnumFacing side : EnumFacing.values()) {
            BlockPos neighbor = support.offset(side);
            Block b = mc.theWorld.getBlockState(neighbor).getBlock();
            if (!b.isAir(mc.theWorld, neighbor)) {
                Vec3 hit = new Vec3(neighbor.getX() + 0.5D,
                        neighbor.getY() + 0.5D,
                        neighbor.getZ() + 0.5D);

                mc.playerController.onPlayerRightClick(
                        mc.thePlayer, mc.theWorld, held,
                        neighbor, side.getOpposite(), hit);
                mc.thePlayer.swingItem();
                break;
            }
        }
    }

    private int MathHelperFloor(double v) {
        return (int)Math.floor(v);
    }
}
