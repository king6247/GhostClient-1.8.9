package com.ghostclient;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class AimBot {
    private final Minecraft mc = Minecraft.getMinecraft();

    @SubscribeEvent
    public void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !GhostClient.aimBot) return;
        if (mc.thePlayer == null || mc.theWorld == null) return;

        EntityLivingBase target = null;
        double best = 6.0;

        for (Object o : mc.theWorld.loadedEntityList) {
            if (!(o instanceof EntityPlayer)) continue;
            EntityPlayer p = (EntityPlayer)o;
            if (p == mc.thePlayer || p.isDead || p.getHealth() <= 0) continue;
            if (mc.thePlayer.getDistanceToEntity(p) > 6.0) continue;

            double d = mc.thePlayer.getDistanceToEntity(p);
            if (d < best) {
                best = d;
                target = p;
            }
        }

        if (target != null) {
            double dx = target.posX - mc.thePlayer.posX;
            double dz = target.posZ - mc.thePlayer.posZ;
            double dy = (target.posY + target.getEyeHeight()) -
                        (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());

            float yaw = (float)(Math.atan2(dz, dx) * 180.0D / Math.PI) - 90.0F;
            float pitch = (float)-(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))
                    * 180.0D / Math.PI);

            mc.thePlayer.rotationYaw = updateRotation(mc.thePlayer.rotationYaw, yaw, 12.0F);
            mc.thePlayer.rotationPitch = updateRotation(mc.thePlayer.rotationPitch, pitch, 12.0F);
        }
    }

    private float updateRotation(float current, float target, float maxChange) {
        float delta = MathHelper.wrapAngleTo180_float(target - current);
        if (delta > maxChange) delta = maxChange;
        if (delta < -maxChange) delta = -maxChange;
        return current + delta;
    }
}
