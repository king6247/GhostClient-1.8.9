# GhostClient 1.8.9

Private Forge 1.8.9 test client.

## Features
- R: Auto Click
- G: Aim Bot
- B: Auto Bridge

## Build
Use Java 8 and ForgeGradle 2.1 with Minecraft Forge 1.8.9-11.15.1.2318.

Commands:
    gradlew setupDecompWorkspace
    gradlew build

The resulting JAR is in:
    build/libs/

## Notes
This is source code for a private/test server. The AutoBridge implementation is intentionally basic and may need tuning for your server/client movement settings.
